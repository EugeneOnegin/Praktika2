import java.util.Scanner;

public class Insert {
    Scanner console = new Scanner(System.in);
    public String filling()
    {
        String path = console.nextLine();
        return path;
    }
}
